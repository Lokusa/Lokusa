// support-modal.component.ts
import { Component } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-support-modal',
  template: `
    <ion-header>
      <ion-toolbar>
        <ion-title>Support</ion-title>
        <ion-buttons slot="end">
          <ion-button (click)="dismiss()">
            <ion-icon name="close"></ion-icon>
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>
    <ion-content class="ion-padding">
      <p>Hello there! 👋 Need assistance? Our dedicated support team is here to help! You can reach us via email at supportexample.com or by phone at +27 12 456 890. Whether you have questions about our menu, need help placing an order, or have any other inquiries, we're just a message or call away. Your satisfaction is our priority, and we're committed to providing you with the best dining experience possible. Thank you for choosing us! 🍽️</p>
    </ion-content>
  `,
})
export class SupportModalComponent {
  constructor(private modalController: ModalController) {}

  dismiss() {
    this.modalController.dismiss();
  }
}
