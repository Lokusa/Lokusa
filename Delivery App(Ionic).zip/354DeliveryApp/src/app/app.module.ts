import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { IonicModule } from '@ionic/angular';

import { AppComponent } from './app.component';
import { AppRoutingModule } from './app-routing.module';
import { PaymentSuccessModalComponent } from './payment-success-modal/payment-success-modal.component';
import { AccountService } from '../app/services/account.service';
import { SupportModalComponent } from '../app/success-modal/success-modal.component';


@NgModule({
  declarations: [
    AppComponent,
    PaymentSuccessModalComponent,
    SupportModalComponent
  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(),
    AppRoutingModule,
    RouterModule.forRoot([]),
   
  ],
  providers: [AccountService],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA] // Add CUSTOM_ELEMENTS_SCHEMA here
})
export class AppModule {}
