import { Injectable } from '@angular/core';
import { Restaurant } from '../models/restaurant.model';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  private ordersKey = 'orders';
  private cartKey = 'cart';
  
  constructor() { }

  // Method to add an order
  addOrder(order: any) {
    let orders = this.getOrdersFromStorage();
    orders.push(order);
    this.saveOrdersToStorage(orders);
  }

  // Method to get all orders
  getOrders(): any[] {
    return this.getOrdersFromStorage();
  }

  // Method to get past orders
  getPastOrders(): any[] {
    // Retrieve all orders from storage
    const allOrders = this.getOrdersFromStorage();
    // Filter orders to get past orders (assuming past orders are orders that are not in the cart)
    const pastOrders = allOrders.filter(order => !this.isOrderInCart(order));
    return pastOrders;
  }

  // Method to update orders
  updateOrders(updatedOrders: any[]) {
    this.saveOrdersToStorage(updatedOrders);
  }

  // Method to clear all orders
  clearOrders() {
    localStorage.removeItem(this.ordersKey);
  }

  // Method to add a restaurant to the cart
  addToCart(restaurant: Restaurant) {
    let cart = this.getCartFromStorage();
    cart.push(restaurant);
    this.saveCartToStorage(cart);
  }

  updateCart(updatedCart: Restaurant[]) {
    this.saveCartToStorage(updatedCart);
  }
  
  clearCart() {
    localStorage.removeItem(this.cartKey);
  }
  
  // Method to retrieve items from the cart
  getCart(): Restaurant[] {
    return this.getCartFromStorage();
  }

  // Helper method to retrieve orders from localStorage
  private getOrdersFromStorage(): any[] {
    const ordersString = localStorage.getItem(this.ordersKey);
    return ordersString ? JSON.parse(ordersString) : [];
  }

  // Helper method to save orders to localStorage
  private saveOrdersToStorage(orders: any[]) {
    localStorage.setItem(this.ordersKey, JSON.stringify(orders));
  }

  // Helper method to retrieve cart items from localStorage
  private getCartFromStorage(): Restaurant[] {
    const cartString = localStorage.getItem(this.cartKey);
    return cartString ? JSON.parse(cartString) : [];
  }

  // Helper method to save cart items to localStorage
  private saveCartToStorage(cart: Restaurant[]) {
    localStorage.setItem(this.cartKey, JSON.stringify(cart));
  }

  // Helper method to check if an order is in the cart
  private isOrderInCart(order: any): boolean {
    const cart = this.getCartFromStorage();
    // Check if the order exists in the cart based on some identifier (e.g., order ID)
    return cart.some(item => item.id === order.id);
  }
}
