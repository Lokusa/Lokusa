// search.service.ts

import { Injectable } from '@angular/core';
import { Restaurant } from '../models/restaurant.model';

@Injectable({
  providedIn: 'root'
})
export class SearchService {
  private restaurants: Restaurant[] = [
    {
      id: 1,
      name: 'Wrap Land ',
      type: 'Italian',
      ratings: 4.5,
      distance: 1.3,
      price: 120,
      topDishImage: 'assets/Picture 13.jpg'
    },
    {
      id: 2,
      name: 'Mother of Pizza',
      type: 'Maxican',
      ratings: 4.5,
      distance: 8.3,
      price: 130,
      topDishImage: 'assets/Picture 3.jpg'
    },
    {
      id: 3,
      name: ' Dijo Tsa Africa',
      type: 'African',
      ratings: 5,
      distance: 1.8,
      price: 100,
      topDishImage: 'assets/Picture 6.jpg'
    },
    {
      id: 4,
      name: 'Asian Best',
      type: 'Asian',
      ratings: 5,
      distance: 1.0,
      price: 150,
      topDishImage: 'assets/Picture 7.jpg'
    },
   
  ];

  constructor() { }

  searchRestaurants(searchTerm: string, criteria: string): Restaurant[] {
    // Filter restaurants based on search criteria
    return this.restaurants.filter(restaurant => {
      return restaurant.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
             restaurant.type.toLowerCase().includes(searchTerm.toLowerCase()) ||
             restaurant.price.toString() === searchTerm ||
             // Add more criteria as needed
             restaurant[criteria as keyof Restaurant].toString() === searchTerm;

    });
  }
}
