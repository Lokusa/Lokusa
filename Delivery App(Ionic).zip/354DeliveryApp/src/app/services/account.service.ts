import { Injectable } from '@angular/core';
import { Order } from '../models/order.model';
import { User } from '../models/user.model';
import { OrderService } from './order.service'; // Import OrderService to access cart data

@Injectable({
  providedIn: 'root'
})
export class AccountService {
  private user: User = {
    id: '1',
    name: 'Lokusa Thwala',
    email: 'thwalambali@gmail.com',
    // Add more user details as needed
  };

  constructor(private orderService: OrderService) {}

  getUser(): User {
    return this.user;
  }

  // Method to get past orders from the local storage of the cart
  getPastOrders(): Order[] {
    return this.orderService.getPastOrders();
  }

  updateUser(updatedUser: User) {
    this.user = updatedUser;
  }
}
