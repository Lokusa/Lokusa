import { NgModule } from '@angular/core';
import { IonicModule } from '@ionic/angular';

@NgModule({
  declarations: [], // Remove PaymentSuccessModalComponent from here
  imports: [IonicModule],
  exports: []
})
export class PaymentSuccessModalModule {}
