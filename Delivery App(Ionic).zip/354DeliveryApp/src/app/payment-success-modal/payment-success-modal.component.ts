import { Component } from '@angular/core';
import { ModalController } from '@ionic/angular';

@Component({
  selector: 'app-payment-success-modal',
  templateUrl: './payment-success-modal.component.html', // Relative path to the HTML template file
  styleUrls: ['./payment-success-modal.component.scss'],
})

export class PaymentSuccessModalComponent {

  constructor(private modalController: ModalController) {}

  dismiss() {
    this.modalController.dismiss();
  }
}
