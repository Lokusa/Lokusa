export interface Order {
    id: string;
    date: Date;
    // Other order properties
  }
  