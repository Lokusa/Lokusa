export interface Restaurant {
    id: number;
    name: string;
    type: string;
    ratings: number;
    distance: number;
    price: number;
    topDishImage: string; // Added property for top dish image
  }
  