import { Component, OnInit } from '@angular/core';
import { AccountService } from '../../services/account.service';
import { Order } from '../../models/order.model';
import { User } from '../../models/user.model';
import { ModalController } from '@ionic/angular'; // Import ModalController
import { SupportModalComponent } from '../../success-modal/success-modal.component'; 
import { Router } from '@angular/router';

@Component({
  selector: 'app-account',
  templateUrl: './account.page.html',
  styleUrls: ['./account.page.scss']
})
export class AccountComponent implements OnInit {
  user: User;
  pastOrders: Order[];
  isEditMode: boolean = false; // New property to track edit mode
  selectedOrder: Order | null = null; // Property to hold the selected order

  constructor(
    private accountService: AccountService,
    private modalController: ModalController, // Inject ModalController
    private router: Router // Inject Router
  ) {
    this.user = {} as User;
    this.pastOrders = [];
  }

  ngOnInit(): void {
    this.getUserData();
  }

  getUserData() {
    this.user = this.accountService.getUser();
    this.pastOrders = this.accountService.getPastOrders();
  }

  toggleEditMode() {
    this.isEditMode = !this.isEditMode; // Toggle edit mode
  }

  saveUserData() {
    // Save user data to account service
    this.accountService.updateUser(this.user);
    this.toggleEditMode(); // Exit edit mode after saving
  }

  async openSupportModal() {
    const modal = await this.modalController.create({
      component: SupportModalComponent,
      cssClass: 'support-modal'
    });
    await modal.present();
  }

  reorder(order: Order) {
    // Navigate to the cart page with the order information
    this.router.navigate(['/cart'], { queryParams: { order: JSON.stringify(order) } });
  }
}
