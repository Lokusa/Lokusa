import { Component } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { OrderService } from '../../services/order.service';
import { Restaurant } from '../../models/restaurant.model';
import { PaymentSuccessModalComponent } from '../../payment-success-modal/payment-success-modal.component';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.page.html',
  styleUrls: ['./cart.page.scss'],
})
export class CartPage {
  orders: Restaurant[] = []; // Array to store orders
  deliveryPrice: number = 35; // Fixed delivery price
  deliveryInstructions: string = ''; // Delivery instructions entered by the user

  constructor(
    private modalController: ModalController,
    private orderService: OrderService
  ) {
    this.orders = this.orderService.getCart(); // Retrieve cart items from OrderService
  }

  // Method to remove an order
  removeOrder(index: number) {
    this.orders.splice(index, 1);
    this.updateCart();
  }

  // Method to clear all orders
  clearOrders() {
    this.orderService.clearCart();
    this.orders = [];
  }

  // Method to update the cart
  updateCart() {
    this.orderService.updateCart(this.orders);
  }

  // Method to calculate the total cost of the order
  calculateTotal(): number {
    let total = 0;
    for (let order of this.orders) {
      total += order.price; // Sum up the product prices
    }
    return total + this.deliveryPrice; // Add delivery charges
  }

  // Method to open the payment success modal
  async openPaymentSuccessModal() {
    const modal = await this.modalController.create({
      component: PaymentSuccessModalComponent,
      cssClass: 'payment-modal'
    });
    return await modal.present();
  }

  // Method to simulate payment process
  async makePayment() {
    // Simulate payment process
    await this.simulatePayment();

    // Open payment success modal
    this.openPaymentSuccessModal();
  }

  // Method to simulate payment delay
  async simulatePayment() {
    // Simulate payment delay
    await new Promise(resolve => setTimeout(resolve, 2000));
  }
}
