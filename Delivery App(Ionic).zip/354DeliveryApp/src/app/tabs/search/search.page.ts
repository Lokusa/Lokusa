import { Component, OnInit } from '@angular/core';
import { SearchService } from '../../services/search.service';
import { Restaurant } from '../../models/restaurant.model';
import { OrderService } from '../../services/order.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.page.html',
  styleUrls: ['./search.page.scss'],
})
export class SearchPage implements OnInit {
  searchTerm: string = '';
  selectedCriteria: string = 'name';
  searchResults: Restaurant[] = [];

  constructor(private searchService: SearchService, private orderService: OrderService) { }

  ngOnInit() {
  }

  search() {
    if (this.searchTerm.trim() !== '') {
      this.searchResults = this.searchService.searchRestaurants(this.searchTerm, this.selectedCriteria);
    } else {
      // If search term is empty, clear the search results
      this.searchResults = [];
    }
  }

  addToCart(restaurant: Restaurant) {
    this.orderService.addToCart(restaurant);
    console.log("Added to cart:", restaurant); // Check in console if restaurant is added to the cart
  }
  
}
