import { Component, ViewChild, AfterViewInit } from '@angular/core';
import Swiper from 'swiper';
import { OrderService } from '../../services/order.service';
import { Restaurant } from '../../models/restaurant.model';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements AfterViewInit {

  @ViewChild('bannerSlider') bannerSlider: any;

  restaurants = [
    {
      id: 1,
      name: 'Wrap Land ',
      type: 'Italian',
      ratings: 4.5,
      distance: 1.3,
      price: 120,
      topDishImage: 'assets/Picture 13.jpg'
    },
    {
      id: 2,
      name: 'Mother of Pizza',
      type: 'Maxican',
      ratings: 4.5,
      distance: 8.3,
      price: 130,
      topDishImage: 'assets/Picture 3.jpg'
    },
    {
      id: 3,
      name: ' Dijo Tsa Africa',
      type: 'African',
      ratings: 5,
      distance: 1.8,
      price: 100,
      topDishImage: 'assets/Picture 6.jpg'
    },
    {
      id: 4,
      name: 'Asian Best',
      type: 'Asian',
      ratings: 5,
      distance: 1.0,
      price: 150,
      topDishImage: 'assets/Picture 7.jpg'
    },
  ];

  stars = Array(5).fill('star');

  slideshowImages: string[] = [
    'assets/Picture 15.jpg',
    'assets/Picture 13.jpg',
    'assets/Picture 7.jpg',
    'assets/Picture 16.jpg',
    'assets/Picture 14.jpg',
    'assets/Picture 15.jpg',
    'assets/Picture 9.jpg',
    'assets/Picture 15.jpg',
    'assets/Picture 13.jpg',
    'assets/Picture 7.jpg',
    'assets/Picture 16.jpg',
    'assets/Picture 14.jpg',
    'assets/Picture 15.jpg',
    'assets/Picture 9.jpg',
    'assets/Picture 15.jpg',
    'assets/Picture 13.jpg',
    'assets/Picture 7.jpg',
    'assets/Picture 16.jpg',
    'assets/Picture 14.jpg',
    'assets/Picture 15.jpg',
    'assets/Picture 9.jpg',
    'assets/Picture 15.jpg',
    'assets/Picture 13.jpg',
    'assets/Picture 7.jpg',
    'assets/Picture 16.jpg',
    'assets/Picture 14.jpg',
    'assets/Picture 15.jpg',
    'assets/Picture 9.jpg',
    'assets/Picture 15.jpg',
    'assets/Picture 13.jpg',
    'assets/Picture 7.jpg',
    'assets/Picture 16.jpg',
    'assets/Picture 14.jpg',
    'assets/Picture 15.jpg',
    'assets/Picture 9.jpg',
    'assets/Picture 15.jpg',
    'assets/Picture 13.jpg',
    'assets/Picture 7.jpg',
    'assets/Picture 16.jpg',
    'assets/Picture 14.jpg',
    'assets/Picture 15.jpg',
    'assets/Picture 9.jpg',
    'assets/Picture 15.jpg',
    'assets/Picture 13.jpg',
    'assets/Picture 7.jpg',
    'assets/Picture 16.jpg',
    'assets/Picture 14.jpg',
    'assets/Picture 15.jpg',
    'assets/Picture 9.jpg',
    'assets/Picture 15.jpg',
    'assets/Picture 13.jpg',
    'assets/Picture 7.jpg',
    'assets/Picture 16.jpg',
    'assets/Picture 14.jpg',
    'assets/Picture 15.jpg',
    'assets/Picture 9.jpg',
    'assets/Picture 15.jpg',
    'assets/Picture 13.jpg',
    'assets/Picture 7.jpg',
    'assets/Picture 16.jpg',
    'assets/Picture 14.jpg',
    'assets/Picture 15.jpg',
    'assets/Picture 9.jpg',
    'assets/Picture 15.jpg',
    'assets/Picture 9.jpg',
    'assets/Picture 15.jpg',
    'assets/Picture 13.jpg',
    'assets/Picture 7.jpg',
    'assets/Picture 16.jpg',
    'assets/Picture 14.jpg',
  ];

  slideOpts = {
    initialSlide: 0,
    speed: 400,
    autoplay: {
      delay: 2000,
    },
    slidesPerView: 1,
    loop: true,
    noSwiping: true, // Disable built-in slide animation
  };

  constructor(private orderService: OrderService) {}

  ngAfterViewInit() {
    new Swiper(this.bannerSlider.nativeElement, this.slideOpts);
  }

  addToCart(restaurant: Restaurant) {
    this.orderService.addToCart(restaurant);
  }
}
